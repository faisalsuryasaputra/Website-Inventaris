<?php

include "../../koneksi.php";


date_default_timezone_set('Asia/Jakarta');

$koneksi = new mysqli("localhost", "root", "", "inventaris");
$bulan1 = $_POST['bulan'];
$tahun = $_POST['tahun'];

 function format_indo($date){
    $BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");

    $tahun = substr($date, 0, 4);               
    $bulan = substr($date, 5, 2);
    $tgl   = substr($date, 8, 2);
    $result = $tgl . " " . $BulanIndo[(int)$bulan-1]. " ". $tahun;
    return($result);
    }

function bulan_indo($bulan_angka) {
 $bulan1 = array(1=>'JANUARI', 
      'FEBRUARI', 
      'MARET', 
      'APRIL', 
      'MEI', 
      'JUNI', 
      'JULI', 
      'AGUSTUS', 
      'SEPTEMBER', 
      'OKTOBER', 
      'NOVEMBER', 
      'DESEMBER'
     );

 return $bulan1[$bulan_angka];
}
?>

<style>

    @media print{
      input.noPrint{
        display: none;
      }

    }
.img{
width: 900px;
height: auto;
margin-left: 20px;

}
.button {
  background-color: #1E90FF;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.tumblr {
  background-color: #1E90FF;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

</style>
<table class="table table-borderless" style="width: 100%" > 

  <tr>
    <td><center><img src="../../img/logo.png" width="256px" height="256px"></center></td>
  </tr>
  <tr>
    <td style="font-size: 40px;" align="left"><center>SMK Telkom Banjarbaru Kalimantan Selatan</center></td>
  </tr>
    <tr>
      <td><center>Jl. Pangeran Suriansyah No.3, Komet, Kec.Banjarbaru Utara, Kota Banjar Baru, Kalimantan Selatan Fax. (0511) 4705299</center></td>
    </tr>
    <tr>
      <td><center>Kode Pos:70724,Telepon:(0511)7403092,4705299</center></td>
    </tr>
    <tr>
      <td><center>email: smktelkombanjarbaru@smktelkom-bjb.sch.id </center></td>
    </tr>
  </table>
<hr>
   <h3><center><b>LAPORAN PEMINJAMAN BARANG PADA BULAN <?php echo  bulan_indo((int)$bulan1); ?> TAHUN <?php echo $tahun; ?>  </b></center></h3>
<table class="table table-borderless" style="width: 100%"> 
  <tr>
    <th style="text-align: right;">Tanggal Cetak :&nbsp&nbsp<?php echo format_indo(date('Y-m-d'))?> </th>
</tr>
  </table> 
<table border="1" width="100%" style="border-collapse: collapse;">

                                       <thead>
                                        <tr>

   <th width="25px" height="50px">No</th>
   <th width="25px" height="50px">ID Peminjaman</th>
   <th width="25px" height="50px">Nama User</th>
   <th width="25px" height="50px">Barang Peminjaman</th>
   <th width="25px" height="50px">Jenis Barang</th>
   <th width="25px" height="50px">Tanggal Peminjaman</th>
   <th width="25px" height="50px">Jumlah Peminjaman</th>

 </tr>  
    </thead>
    <tbody>
                                     

        <?php
        $no = 1;

        $sql = mysqli_query($koneksi, "SELECT * FROM peminjaman
        INNER JOIN user ON user.id_user=peminjaman.id_user
        INNER JOIN barang ON barang.id_barang=peminjaman.id_barang WHERE YEAR(peminjaman.tgl_pinjam)='$tahun' AND peminjaman.status='Pinjam' AND MONTH(peminjaman.tgl_pinjam)='$bulan1' ");
         while ($data=$sql->fetch_assoc()) {

        ?>
          <tr>
              <td width="25px" height="50px"><center><?php echo $no++;?></center></td> 
              <td width="100px" height="50px"><center><?php echo $data['id_pinjam'];?></center></td>
              <td width="100px" height="50px"><center><?php echo $data['nama_user'];?></center></td>
              <td width="100px" height="50px"><center><?php echo $data['nama_barang'];?></center></td>
              <td width="100px" height="50px"><center><?php echo $data['jenis_barang'];?> </center></td>
              <td width="100px" height="50px"><center><?php echo format_indo(date($data['tgl_pinjam']));?></center></td>
              <td width="100px" height="50px"><center><?php echo $data['jumlah_pinjam'];?> </center></td>                
         </tr>  
        <?php }  ?>
            </tbody> 
            </table>
            <br><p align="right">Banjarmasin,&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo format_indo(date('Y-m'))?> &nbsp
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<br>
            <br>Kepala Sekolah  &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<br> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</br>         
            <br></br>   
            <br></br>
            <br></br>
            <u>SMK Telkom Banjarbaru</u>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</p>
            </div>
            <br></br>
            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
            
            <input type="button" class="noPrint button" value="Cetak" onclick="window.print()">
                      </div>
                  </div>
              </div>
          </div>
    </div>      