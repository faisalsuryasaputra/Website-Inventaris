<?php
$id = $_GET['id'];
$sql = $koneksi->query("SELECT * FROM user WHERE id_user='$id'");
$data = $sql->fetch_assoc();

?>
<div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Quick Example</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="POST">
                <div class="card-body">
                  <div class="form-group">
                    <label>ID User</label>
                    <input type="text" class="form-control" name="id_user" value="<?php echo $data['id_user'];?>" readonly>
                  </div>
                  <div class="form-group">
                    <label>Nama User</label>
                    <input type="text" class="form-control" name="nama_user" value="<?php echo $data['nama_user'];?>">
                  </div>
                  <div class="form-group">
                    <label>Jenis Kelamin</label>
                    <label><input type="radio" name="" id="" <?php if($data['level']=='L') echo 'checked'?>>Laki-Laki</label>
                    <label><input type="radio" name="" id="" <?php if($data['level']=='P') echo 'checked'?>>Perempuan</label>
                  </div>
                  <div class="form-group">
                    <label>Username</label>
                    <input type="text" class="form-control" name="username" value="<?php echo $data['username'];?>">
                  </div>
                  <div class="form-group">
                    <label>Password</label>
                    <input type="password" class="form-control" name="password" value="<?php echo $data['password'];?>">
                  </div>
                  <div class="form-group">
                    <label>Level</label>
                    <input type="text" class="form-control" name="level" value="<?php echo $data['level'];?>">
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="simpan" class="btn btn-success">Simpan</button>
                  <button type="reset"  class="btn btn-info">Reset</button>
                </div>
              </form>
            </div>
<?php
if (isset($_POST['simpan'])) {
    
$id_user = $_POST['id_user'];
$nama_user = $_POST['nama_user'];
$username = $_POST['username'];
$password = $_POST['password'];
$level = $_POST['level'];

    $sql = mysqli_query($koneksi,"UPDATE user SET nama_user='$nama_user',username='$username',password='$password',level='$level' WHERE id_user='$id_user'");

    if ($sql) {
        ?>
        <script>
            alert ('Data Berhasil Di Simpan')
            window.location.href = '?page=user';
        </script>
        <?php
    }

}            
?>