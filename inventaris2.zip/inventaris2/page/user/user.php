<div class="card">
              <div class="card-header">
                <h3 class="card-title">Data User</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                  <a href="?page=user&aksi=tambah" class="btn btn-primary">Tambah Data</a>
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>No.</th>
                    <th>ID User</th>
                    <th>Nama User</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Level</th>
                    <th>Aksi</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  $no = 1;
                  $sql = mysqli_query($koneksi, "SELECT * FROM user");
                  while ($data = $sql->fetch_assoc()) {
                  ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo $data['id_user'];?></td>
                        <td><?php echo $data['nama_user'];?></td>
                        <td><?php echo $data['username'];?></td>
                        <td><?php echo $data['password'];?></td>
                        <td><?php echo $data['level'];?></td>
                        <td>
                            <a href="?page=user&aksi=ubah&id=<?php echo $data['id_user'];?>" class="btn btn-warning">Ubah</a>
                            <a href="?page=user&aksi=hapus&id=<?php echo $data['id_user'];?>" class="btn btn-danger">Hapus</a>
                        </td>
                    </tr>
                    <?php
                    }
                    ?>
                  </tbody>
                  
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->