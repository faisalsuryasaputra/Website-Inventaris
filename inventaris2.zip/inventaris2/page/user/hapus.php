<?php
$id= $_GET['id'];
$sql = mysqli_query($koneksi, "DELETE FROM user WHERE id_user='$id'");
 
 if ($sql) {
    ?>
    <script>
        alert ('Data Berhasil Di Hapus')
        window.location.href = '?page=user';
    </script>
    <?php
 }
?>