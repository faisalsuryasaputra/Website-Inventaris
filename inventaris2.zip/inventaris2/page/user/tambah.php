<div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Quick Example</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="POST">
                <div class="card-body">
                  <div class="form-group">
                    <label>ID User</label>
                    <input type="text" class="form-control" name="id_user" placeholder="Masukkan ID User">
                  </div>
                  <div class="form-group">
                    <label>Nama User</label>
                    <input type="text" class="form-control" name="nama_user" placeholder="Masukkan Nama User">
                  </div>
                  <div class="form-group">
                    <label>Username</label>
                    <input type="text" class="form-control" name="username" placeholder="Masukkan Username">
                  </div>
                  <div class="form-group">
                    <label>Password</label>
                    <input type="password" class="form-control" name="password" placeholder="Masukkan Password">
                  </div>
                  <div class="form-group">
                    <label>Level</label>
                    <input type="text" class="form-control" name="level" placeholder="Masukkan Level">
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="simpan" class="btn btn-success">Simpan</button>
                  <button type="reset"  class="btn btn-info">Reset</button>
                </div>
              </form>
            </div>
<?php
if (isset($_POST['simpan'])) {
    
$id_user = $_POST['id_user'];
$nama_user = $_POST['nama_user'];
$username = $_POST['username'];
$password = $_POST['password'];
$level = $_POST['level'];

    $sql = mysqli_query($koneksi,"INSERT INTO user VALUE('$id_user','$nama_user','$username','$password','$level')");

    if ($sql) {
        ?>
        <script>
            alert ('Data Berhasil Di Simpan')
            window.location.href = '?page=user';
        </script>
        <?php
    }

}            
?>