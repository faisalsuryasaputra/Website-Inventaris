<?php
//mengambil data barang dengan kode paling besar
$sql = mysqli_query($koneksi, "SELECT max(id_pengembalian) as maxid FROM pengembalian");
$data = mysqli_fetch_array($sql);
$id_pengembalian = $data['maxid'];

//mengambil angka dari kode barang terbesar, menggunakan fungsi substr
//dan diubah ke integer dengan (int)
$urutan = (int) substr($id_pengembalian, 3, 3);

//bilangan yang diambil ini ditambah 1 untuk menentukan nomer urut berikutnya
$urutan++;

$huruf = "IDK";
$huruf = $huruf . sprintf("%03s" , $urutan);
?>

<div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Tambah Data Pengembalian Barang</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="POST">
                <div class="card-body">
                  <div class="form-group">
                    <label>ID Pengembalian</label>
                    <input type="text" class="form-control" name="id_pengembalian" value="<?php echo $newID;?>"readonly>
                  </div>
                  <div class="form-group">
                    <label>Peminjaman Barang</label>
                    <select name="id_pinjam" class="form-control">
                      <option value="">--> Pilih Peminjaman <--</option>
                      <?php
                        $sql = mysqli_query($koneksi,"SELECT * FROM peminjaman
                        INNER JOIN barang ON peminjaman.id_barang=barang.id_barang
                        INNER JOIN user ON peminjaman.id_user=user.id_user");
                        while ($option = $sql->fetch_assoc()) {
                      ?>
                      <option value="<?php echo $option['id_pinjam'];?>"><?php echo $option['id_pinjam'];?>/<?php echo $option['nama_user'];?>/<?php echo $option['nama_barang'];?>/<?php echo $option ['jumlah_pinjam'];?></option>
                      <?php    
                        }
                      ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Tanggal Pengembalian</label>
                    <input type="date" class="form-control" name="tgl_pengembalian" placeholder="Masukkan Tanggal">
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="simpan" class="btn btn-success">Simpan</button>
                  <button type="reset"  class="btn btn-info">Reset</button>
                </div>
              </form>
            </div>
<?php
if (isset($_POST['simpan'])) {
    
$id_pengembalian = $_POST['id_pengembalian'];
$id_pinjam = $_POST['id_pinjam'];
$tgl_pengembalian = $_POST['tgl_pengembalian'];


$sql = mysqli_query($koneksi, "INSERT INTO pengembalian VALUE ('$id_pengembalian','$id_pinjam'.'$tgl_pengembalian')");

//jumlah harus kurang dari jumlah_Pinjam
    if ($sql) {

      mysqli_query($koneksi, "UPDATE peminjaman INNER JOIN barang ON peminjaman.id_barang=barang.id_berang SET barang.jumlah=(barang.jumlah+peminjaman.jumlah_pinjam), peminjaman.status='Dikembalikan' WHERE peminjaman.id_pinjam='$id_pinjam'");
      ?>
      <script>
          alert ('Data Berhasil Dikembalikan')
          window.location.href = '?page=pengembalian';
      </script>
      <?php
    }

  }
   
?>