<?php
$id= $_GET['id'];
$jumlah_peminjaman= $_GET['jumlah'];
$id_barang= $_GET['id_barang'];
$id_pinjam= $_GET['id_pinjam'];
$sql = mysqli_query($koneksi, "DELETE FROM pengembalian WHERE id_pengembalian='$id'");

mysqli_query($koneksi, "UPDATE barang SET jumlah=(jumlah-'$jumlah_pengembalian') WHERE id_barang='$id_barang'");
mysqli_query($koneksi, "UPDATE peminjaman SET status='pinjam' WHERE id_pinjam='$id_pinjam'");
 if ($sql) {
    ?>
    <script>
        alert ('Data Berhasil Di Hapus')
        window.location.href = '?page=pengembalian';
    </script>
    <?php
 }
?>