<div class="card">
            <div class="card-header">
              <h3 class="card-title">Data pengembalian</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <a href="?page=pengembalian&aksi=tambah" class="btn btn-primary">Tambah Data</a>
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
              <th>No.</th>
              <th>ID Pengembalian</th>
              <th>ID Peminjaman</th>
              <th>Tanggal Pengembalian</th>
              <th>Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $no = 1;
            $sql = mysqli_query($koneksi, "SELECT * FROM pengembalian
            INNER JOIN peminjaman ON pengembalian.id_pengembalian=peminjaman.id_pinjam");
            while ($data = $sql->fetch_assoc()) {
            ?>
              <tr>
                  <td><?php echo $no++; ?></td>
                  <td><?php echo $data['id_pengembalian'];?></td>
                  <td><?php echo $data['id_pinjam'];?></td>
                  <td><?php echo $data['tgl_pengembalian'];?></td>
                  <td>
                      <a href="?page=pengembalian&aksi=ubah&id=<?php echo $data['id_pengembalian'];?>" class="btn btn-warning">Ubah</a>
                      <a href="?page=pengembalian&aksi=hapus&id=<?php echo $data['id_pengembalian'];?>&jumlah=<?php echo $data['jumlah_pinjam'];?>&id_barang=<?php echo $data['id_barang'];?>&id_pinjam=<?php echo $data['id_pinjam'];?>" class="btn btn-danger">Hapus</a>
                  </td>
                  </tr>
                  <?php
                  }
                  ?>
                </tbody>
                
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->