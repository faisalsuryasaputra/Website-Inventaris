<?php
$id = $_GET['id'];
$sql = $koneksi->query("SELECT * FROM peminjaman 
INNER JOIN user ON user.id_user=peminjaman.id_user
INNER JOIN barang ON barang.id_barang=peminjaman.id_barang
WHERE id_pinjam='$id'");
$data = $sql->fetch_assoc();

?>
<div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Quick Example</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="POST">
                <div class="card-body">
                  <div class="form-group">
                    <label>ID Pinjam</label>
                    <input type="text" class="form-control" name="id_pinjam" value="<?php echo $data['id_pinjam'];?>" readonly>
                  </div>
                  <div class="form-group">
                    <label>Nama User</label>
                    <select name="id_user" class="form-control">
                      <option value="<?php echo $data['id_user']; ?>"><?php echo $data['nama_user']; ?></option>
                      <?php
                        $sql = mysqli_query($koneksi,"SELECT * FROM user");
                        while ($option = $sql->fetch_assoc()) {
                      ?>
                      <option value="<?php echo $option['id_user'];?>"><?php echo $option['nama_user'];?></option>
                      <?php    
                        }
                      ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Barang Dipinjam</label>
                    <select name="id_barang" class="form-control">
                      <option value="<?php echo $data['id_barang']; ?>"><?php echo $data['nama_barang']; ?></option>
                      <?php
                        $sql = mysqli_query($koneksi,"SELECT * FROM barang");
                        while ($option = $sql->fetch_assoc()) {
                      ?>
                      <option value="<?php echo $option['id_barang'];?>"><?php echo $option['nama_barang'];?></option>
                      <?php    
                        }
                      ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Tanggal Peminjaman</label>
                    <input type="date" class="form-control" name="tgl_pinjam" value="<?php echo $data['tgl_pinjam'];?>">
                  </div>
                  <div class="form-group">
                    <label>Jumlah Peminjaman</label>
                    <input type="number" class="form-control" name="jumlah_pinjam" value="<?php echo $data['jumlah_pinjam'];?>">
                    <input type="number" class="form-control" name="jumlah_awal" value="<?php echo $data['jumlah_pinjam'];?>" hidden>
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="simpan" class="btn btn-success">Simpan</button>
                  <button type="reset"  class="btn btn-info">Reset</button>
                </div>
              </form>
            </div>
<?php
if (isset($_POST['simpan'])) {
    
$id_pinjam = $_POST['id_pinjam'];
$id_user = $_POST['id_user'];
$id_barang = $_POST['id_barang'];
$tgl_pinjam = $_POST['tgl_pinjam'];
$jumlah_pinjam = $_POST['jumlah_pinjam'];
$jumlah_awal = $_POST['jumlah_awal'];

    $sql = mysqli_query($koneksi,"UPDATE peminjaman SET id_user='$id_user',id_barang='$id_barang',tgl_pinjam='$tgl_pinjam',jumlah_pinjam='$jumlah_pinjam' WHERE id_pinjam='$id_pinjam' ");
    
    mysqli_query($koneksi, "UPDATE barang SET jumlah=(jumlah+'$jumlah_awal'-'$jumlah_pinjam') WHERE id_barang='$id_barang'");

    if ($sql) {
        ?>
        <script>
            alert ('Data Berhasil Di Ubah')
            window.location.href = '?page=peminjaman';
        </script>
        <?php
    }

}            
?>