<?php
$id= $_GET['id'];
$jumlah_peminjaman= $_GET['jumlah'];
$id_barang= $_GET['id_barang'];
$sql = mysqli_query($koneksi, "DELETE FROM peminjaman WHERE id_pinjam='$id'");

mysqli_query($koneksi, "UPDATE barang SET jumlah=(jumlah+'$jumlah_peminjaman') WHERE id_barang='$id_barang'");
 if ($sql) {
    ?>
    <script>
        alert ('Data Berhasil Di Hapus')
        window.location.href = '?page=peminjaman';
    </script>
    <?php
 }
?>