<div class="card">
            <div class="card-header">
              <h3 class="card-title">Data Peminjaman</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <a href="?page=peminjaman&aksi=tambah" class="btn btn-primary">Tambah Data</a>
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
              <th>No.</th>
              <th>ID Peminjaman</th>
              <th>Nama User</th>
              <th>Barang Dipinjam</th>
              <th>Jenis Barang</th>
              <th>Tanggal Peminjaman</th>
              <th>Jumlah Peminjaman</th>
              <th>Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $no = 1;
            $sql = mysqli_query($koneksi, "SELECT * FROM peminjaman
            INNER JOIN user ON user.id_user=peminjaman.id_user
            INNER JOIN barang ON barang.id_barang=peminjaman.id_barang ");
            while ($data = $sql->fetch_assoc()) {
            ?>
              <tr>
                  <td><?php echo $no++; ?></td>
                  <td><?php echo $data['id_pinjam'];?></td>
                  <td><?php echo $data['nama_user'];?></td>
                  <td><?php echo $data['nama_barang'];?></td>
                  <td><?php echo $data['jenis_barang'];?></td>
                  <td><?php echo $data['tgl_pinjam'];?></td>
                  <td><?php echo $data['jumlah_pinjam'];?></td>
                  <td>
                      <a href="?page=peminjaman&aksi=ubah&id=<?php echo $data['id_pinjam'];?>" class="btn btn-warning">Ubah</a>
                      <a href="?page=peminjaman&aksi=hapus&id=<?php echo $data['id_pinjam'];?>&jumlah=<?php echo $data['jumlah_pinjam'];?>&id_barang=<?php echo $data['id_barang'];?>" class="btn btn-danger">Hapus</a>
                  </td>
                  </tr>
                  <?php
                  }
                  ?>
                </tbody>
                
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->