<div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Tambah Data Peminjaman Barang</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="POST">
                <div class="card-body">
                  <div class="form-group">
                    <label>ID Pinjam</label>
                    <input type="text" class="form-control" name="id_pinjam" placeholder="Masukkan ID Pinjam">
                  </div>
                  <div class="form-group">
                    <label>Nama User</label>
                    <select name="id_user" class="form-control">
                      <option value="">--> Pilih User <--</option>
                      <?php
                        $sql = mysqli_query($koneksi,"SELECT * FROM user");
                        while ($option = $sql->fetch_assoc()) {
                      ?>
                      <option value="<?php echo $option['id_user'];?>"><?php echo $option['nama_user'];?></option>
                      <?php    
                        }
                      ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Barang Dipinjam</label>
                    <select name="id_barang" class="form-control">
                      <option value="">--> Pilih Barang <--</option>
                      <?php
                        $sql = mysqli_query($koneksi,"SELECT * FROM barang");
                        while ($option = $sql->fetch_assoc()) {
                      ?>
                      <option value="<?php echo $option['id_barang'];?>"><?php echo $option['nama_barang'];?></option>
                      <?php    
                        }
                      ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Tanggal Peminjaman</label>
                    <input type="date" class="form-control" name="tgl_pinjam" placeholder="Masukkan Tanggal">
                  </div>
                  <div class="form-group">
                    <label>Jumlah Peminjaman</label>
                    <input type="number" class="form-control" name="jumlah_pinjam" placeholder="Masukkan Jumlah">
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="simpan" class="btn btn-success">Simpan</button>
                  <button type="reset"  class="btn btn-info">Reset</button>
                </div>
              </form>
            </div>
<?php
if (isset($_POST['simpan'])) {
    
$id_pinjam = $_POST['id_pinjam'];
$id_user = $_POST['id_user'];
$id_barang = $_POST['id_barang'];
$tgl_pinjam = $_POST['tgl_pinjam'];
$jumlah_pinjam = $_POST['jumlah_pinjam'];

    $sql2 = mysqli_query($koneksi, "SELECT * FROM barang WHERE id_barang='$id_barang'");
    $data2= $sql2->fetch_assoc();
    $jumlah = $data2['jumlah'];

//jumlah harus kurang dari jumlah_Pinjam
    if ($jumlah<$jumlah_pinjam) {
      ?>
      <script>
          alert ('Stok Melebihi Kouta')
          window.location.href = '?page=peminjaman&aksi=tambah';
      </script>
      <?php
    }

    else {
      $sql = mysqli_query($koneksi,"INSERT INTO peminjaman VALUE ('$id_pinjam','$id_user','$id_barang','$tgl_pinjam','$jumlah_pinjam','pinjam')");
      mysqli_query($koneksi, "UPDATE barang SET jumlah=(jumlah-'$jumlah_pinjam') WHERE id_barang='$id_barang'");
        ?>
        <script>
            alert ('Data Berhasil Di Simpan')
            window.location.href = '?page=peminjaman';
        </script>
        <?php
    }
}             
?>