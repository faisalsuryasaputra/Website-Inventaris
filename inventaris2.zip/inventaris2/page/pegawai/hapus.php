<?php
$id= $_GET['id'];
$sql = mysqli_query($koneksi, "DELETE FROM pegawai WHERE id_pegawai='$id'");
 
 if ($sql) {
    ?>
    <script>
        alert ('Data Berhasil Di Hapus')
        window.location.href = '?page=pegawai';
    </script>
    <?php
 }
?>