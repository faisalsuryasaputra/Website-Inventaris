<?php
$id = $_GET['id'];
$sql = $koneksi->query("SELECT * FROM pegawai WHERE id_pegawai='$id'");
$data = $sql->fetch_assoc();

?>
<div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Quick Example</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="POST">
                <div class="card-body">
                  <div class="form-group">
                    <label>ID Pegawai</label>
                    <input type="text" class="form-control" name="id_pegawai" value="<?php echo $data['id_pegawai'];?>" readonly>
                  </div>
                  <div class="form-group">
                    <label>Nama Pegawai</label>
                    <input type="text" class="form-control" name="nama_pegawai" value="<?php echo $data['nama_pegawai'];?>">
                  </div>
                  <div class="form-group">
                  <label>Jabatan</label>
                    <select name="jabatan" class="form-control">
                    <option value="<?php echo $data['jabatan'];?>"><?php echo $data['jabatan'];?></option>
                      <option value="HRD">HRD</option>
                      <option value="Pegawai">Pegawai</option>
                    </select>
                  </div>
                  <div class="form-group">
                  <label>Jenis Kelamin</label>
                  <select name="jenis_kelamin" class="form-control">
                  <option value="<?php echo $data['jenis_kelamin'];?>"><?php echo $data['jenis_kelamin'];?></option>
                      <option value="Laki-laki">Laki-Laki</option>
                      <option value="Perempuan">Perempuan</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>No Telepon</label>
                    <input type="text" class="form-control" name="no_telp" value="<?php echo $data['no_telp'];?>">
                  </div>
                  <div class="form-group">
                    <label>Alamat</label>
                    <input type="text" class="form-control" name="alamat" value="<?php echo $data['alamat'];?>">
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="simpan" class="btn btn-success">Simpan</button>
                  <button type="reset"  class="btn btn-info">Reset</button>
                </div>
              </form>
            </div>
<?php
if (isset($_POST['simpan'])) {
    
$id_pegawai = $_POST['id_pegawai'];
$nama_pegawai = $_POST['nama_pegawai'];
$jabatan = $_POST['jabatan'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$no_telp = $_POST['no_telp'];
$alamat = $_POST['alamat'];

    $sql = mysqli_query($koneksi,"UPDATE pegawai SET nama_pegawai='$nama_pegawai',jabatan='$jabatan',jenis_kelamin='$jenis_kelamin',no_telp='$no_telp',alamat='$alamat' WHERE id_pegawai='$id_pegawai'");

    if ($sql) {
        ?>
        <script>
            alert ('Data Berhasil Di Simpan')
            window.location.href = '?page=pegawai';
        </script>
        <?php
    }

}            
?>