<?php
$id = $_GET['id'];
$sql = $koneksi->query("SELECT * FROM barang WHERE id_barang='$id'");
$data = $sql->fetch_assoc();

?>
<div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Ubah Data Barang</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="POST">
                <div class="card-body">
                  <div class="form-group">
                    <label>ID Barang</label>
                    <input type="text" class="form-control" name="id_barang" value="<?php echo $data['id_barang'];?>" readonly>
                  </div>
                  <div class="form-group">
                    <label>Nama Barang</label>
                    <input type="text" class="form-control" name="nama_barang" value="<?php echo $data['nama_barang'];?>">
                  </div>
                  <div class="form-group">
                    <label>Jenis Barang</label>
                    <select name="jenis_barang" class="form-control">
                      <option value="<?php echo $data['jenis_barang'];?>"><?php echo $data['jenis_barang'];?></option>
                      <option value="Hardware">Hardware</option>
                      <option value="Aksesoris">Aksesoris</option>
                      <option value="Alat">Alat</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>jumlah</label>
                    <input type="number" class="form-control" name="jumlah" value="<?php echo $data['jumlah'];?>">
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="simpan" class="btn btn-success">Simpan</button>
                  <button type="reset"  class="btn btn-info">Reset</button>
                </div>
              </form>
            </div>
<?php
if (isset($_POST['simpan'])) {
    
$id_barang = $_POST['id_barang'];
$nama_barang = $_POST['nama_barang'];
$jenis_barang = $_POST['jenis_barang'];
$jumlah = $_POST['jumlah'];

    $sql = mysqli_query($koneksi,"UPDATE barang SET nama_barang='$nama_barang',jenis_barang='$jenis_barang',jumlah='$jumlah' WHERE id_barang='$id_barang'");

    if ($sql) {
        ?>
        <script>
            alert ('Data Berhasil Di Simpan')
            window.location.href = '?page=barang';
        </script>
        <?php
    }

}            
?>