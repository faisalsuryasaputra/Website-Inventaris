<div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Tambah Data Barang</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="POST">
                <div class="card-body">
                  <div class="form-group">
                    <label>ID Barang</label>
                    <input type="text" class="form-control" name="id_barang" placeholder="Masukkan ID barang">
                  </div>
                  <div class="form-group">
                    <label>Nama Barang</label>
                    <input type="text" class="form-control" name="nama_barang" placeholder="Masukkan Nama barang">
                  </div>
                  <div class="form-group">
                    <label>Jenis Barang</label>
                    <select name="jenis_barang" class="form-control">
                      <option value="">--> Pilih Jenis <--</option>
                      <option value="Hardware">Hardware</option>
                      <option value="Aksesoris">Aksesoris</option>
                      <option value="Alat">Alat</option>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Jumlah</label>
                    <input type="text" class="form-control" name="jumlah" placeholder="Masukkan Jumlah">
                  </div>
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" name="simpan" class="btn btn-success">Simpan</button>
                  <button type="reset"  class="btn btn-info">Reset</button>
                </div>
              </form>
            </div>
<?php
if (isset($_POST['simpan'])) {
    
$id_barang = $_POST['id_barang'];
$nama_barang = $_POST['nama_barang'];
$jenis_barang = $_POST['jenis_barang'];
$jumlah = $_POST['jumlah'];

    $sql = mysqli_query($koneksi,"INSERT INTO barang VALUE('$id_barang','$nama_barang','$jenis_barang','$jumlah')");

    if ($sql) {
        ?>
        <script>
            alert ('Data Berhasil Di Simpan')
            window.location.href = '?page=barang';
        </script>
        <?php
    }

}            
?>